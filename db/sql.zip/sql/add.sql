INSERT INTO banners (id, title, content, button, link, image, created)
VALUES (
    DEFAULT,
    'Осуществите свои мечты',
    'Вкладывайте депозит в Алифе и получайте больше половины от дохода',
    'Вкладывать',
    'https://alif.tj/deposit#CountYourIncome',
    'granat.svg',
    DEFAULT
  );